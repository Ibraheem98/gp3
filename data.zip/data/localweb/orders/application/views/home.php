<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8" />
	<style>
		body{
			background-color: #FFFFEF;
			
			
		}
		h1 { text-align: center; 	font-family: Calibri; }
		p.p-centre { text-align: center; font-family: Arial; }
		#cogs { display: block; padding-top: 20px; margin-left: auto; margin-right: auto; }		
		
		.paragraph{
		display: block;
		line-height: 1.5;
		margin-left: auto;
		margin-right:auto;
		width:80%;
		text-align:justify;
		font-size: 25px;
		font-family: Arial;
		padding: 20px;
		border: 7px solid grey;
				
		}
		
		
		
		
	</style>
</head>
<body>

<h1>MICE Booking System</h1>

<div class = "paragraph">
	<p class="p-centre">Welcome to the MICE booking system.</p>
	<p class="p-centre">Click one of the navigation links to begin.</p>
</div>
<div align="center">
	<img id="cogs" src="assets/images/cinema.jpg" alt="Cogs and gears" height="260" width="380">
	<!--Image credits: http://www.wallpaperdecor.com.au/murals/scandinavian-wallpaper-decor/typography-collection/cogs-gears-e21324/ -->
</div>
</body>
</html>
